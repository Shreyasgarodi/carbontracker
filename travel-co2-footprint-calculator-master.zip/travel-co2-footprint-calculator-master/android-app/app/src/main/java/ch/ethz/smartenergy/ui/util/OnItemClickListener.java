package ch.ethz.smartenergy.ui.util;

public interface OnItemClickListener {
    public void onItemClickListener(int position);
}
