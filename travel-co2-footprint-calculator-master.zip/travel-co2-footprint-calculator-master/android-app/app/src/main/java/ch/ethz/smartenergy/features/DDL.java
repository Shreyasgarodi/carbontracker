package ch.ethz.smartenergy.features;

import java.util.ArrayList;

public class DDL {
    public ArrayList<Double> a, b;
    public DDL(ArrayList<Double> a, ArrayList<Double> b) {
        this.a = a;
        this.b = b;
    }
}