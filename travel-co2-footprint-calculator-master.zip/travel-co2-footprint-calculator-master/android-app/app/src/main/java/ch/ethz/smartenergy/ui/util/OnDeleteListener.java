package ch.ethz.smartenergy.ui.util;

public interface OnDeleteListener {
    void onDeleteClick(int position);
}
